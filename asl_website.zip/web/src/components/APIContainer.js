import React from 'react';
import '../styles/Pages.css';

const APIContainer = ({ label }) => {
  return (
    <div className="api-container">
      <p>{label} API Container</p>
    </div>
  );
};

export default APIContainer;
