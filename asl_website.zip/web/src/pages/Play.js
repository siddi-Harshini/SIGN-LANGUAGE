import React from 'react';
import '../styles/Pages.css';

const Play = () => {
  return (
    <div className="page play-page">
      <h1>Play ASL Games</h1>
      <div className="game-box">
        Play Game
      </div>
      <p>Enjoy interactive ASL games!</p>
    </div>
  );
};

export default Play;
